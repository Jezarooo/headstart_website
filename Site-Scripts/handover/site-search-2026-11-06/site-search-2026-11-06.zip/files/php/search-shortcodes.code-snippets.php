<?php

/**
 * Search-Shortcodes
 */
/**
 * Site search: front-end shortcodes and endpoints.
 *
 *   [hs_search]          the search field for the utility bar (results panel drops down from it)
 *   [hs_search_button]   magnifier button for the mobile header (opens the panel as a sheet)
 *
 * Output is the same for every visitor, so page caching (WP Super Cache, Cloudflare APO) is safe.
 * Without JavaScript the field is a normal GET form to /?s=.
 *
 * admin-ajax endpoint (POST, not cached; the search log endpoint is in Search-Terms):
 *   hs_search_index  builds and returns the index only when index.json is missing (at most once per 5 minutes)
 *
 * No rewrite rules: no permalink flush needed.
 */

/** data-hs-index / data-hs-ajax attributes: where the script finds the index and admin-ajax (the same for every visitor). */
function hs_search_paths_attr() {
	$index = wp_make_link_relative( trailingslashit( wp_upload_dir()['baseurl'] ) . 'hs-search/index.json' );
	$ajax  = wp_make_link_relative( admin_url( 'admin-ajax.php' ) );
	return ' data-hs-index="' . esc_attr( $index ) . '" data-hs-ajax="' . esc_attr( $ajax ) . '"';
}

add_shortcode( 'hs_search', 'hs_search_field_shortcode' );
function hs_search_field_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'placeholder' => 'Search the site…' ), $atts, 'hs_search' );
	$icon = '<svg class="hs-search-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';
	return '<div class="hs-search" data-hs-search' . hs_search_paths_attr() . '>'
		. '<form class="hs-search-form" role="search" action="' . esc_url( home_url( '/' ) ) . '" method="get">'
		. $icon
		. '<input class="hs-search-field" type="search" name="s" autocomplete="off" spellcheck="false" placeholder="' . esc_attr( $atts['placeholder'] ) . '" aria-label="Search the site" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="hs-search-panel">'
		. '<button class="hs-search-clear" type="button" aria-label="Clear search" hidden>&#x2715;</button>'
		. '<kbd class="hs-search-key" aria-hidden="true">/</kbd>'
		. '</form></div>';
}

add_shortcode( 'hs_search_button', 'hs_search_button_shortcode' );
function hs_search_button_shortcode() {
	return '<button type="button" class="hs-search-trigger" aria-label="Search the site" aria-haspopup="dialog"' . hs_search_paths_attr() . '>'
		. '<svg class="hs-search-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>'
		. '</button>';
}

/* ---------------------------------------------------------------------------
 * Index fallback: only when index.json is missing
 * ------------------------------------------------------------------------ */
add_action( 'wp_ajax_hs_search_index', 'hs_search_index_fallback' );
add_action( 'wp_ajax_nopriv_hs_search_index', 'hs_search_index_fallback' );
function hs_search_index_fallback() {
	if ( ! function_exists( 'hs_search_index_file' ) || ! function_exists( 'hs_search_run_locked_build' ) ) {
		wp_send_json_error( 'Search index builder is not active.', 503 );
	}
	$file = hs_search_index_file();
	if ( ! file_exists( $file ) && ! get_transient( 'hs_search_fallback_recent' ) ) {
		set_transient( 'hs_search_fallback_recent', 1, 5 * MINUTE_IN_SECONDS );
		hs_search_run_locked_build();
	}
	if ( ! file_exists( $file ) ) {
		wp_send_json_error( 'Index not available yet.', 503 );
	}
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	readfile( $file ); // phpcs:ignore
	exit;
}
