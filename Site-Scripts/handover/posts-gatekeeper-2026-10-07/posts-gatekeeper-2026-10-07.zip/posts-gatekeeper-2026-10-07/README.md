# Posts Gatekeeper: Handover Package
**Date:** 2026-10-07 · **Tested on:** WP 7.1.2, Divi 5.0.0-public-beta.4.1, ACF 6.8.10 (local)
Full technical detail: `DEV-BRIEF-posts-gatekeeper.md`

## Root cause
The old editor check matched Divi's button by its **label**. After a draft is saved, `#et-switch-to-divi` changes from "Use Divi Builder" to "Edit With The Divi Builder", so the check was bypassed. Nothing was checked on the server, and Divi's own Publish button wasn't checked.

## Rules (single source: `hs_post_gate_missing_fields()`)
1. Title
2. Department (`hs_department`) OR Badge Override (`hs_thematic_chip`)
3. Campus (`hs_post_campus`) OR Location Override (`hs_location_override`)
4. Featured Image (landscape hero). A portrait or square image gets an amber warning only. `hs_portrait_image` is optional, slider-only, and doesn't count.

Drafts are never blocked. **Opening Divi** and **publishing** are blocked.

## Changes
**`deploy/posts-divi-gatekeeper.code-snippets.php`** (rewritten)
- Divi detection by ID/class/URL (`#et-switch-to-divi`, `.editor-post-switch-to-divi`, `et_fb=1`, `et_fb_activation_nonce`); label text only as a fallback.
- Editor:
  - Blocks Divi and Publish if anything is missing. Also listens inside `iframe[name="editor-canvas"]`.
  - When everything passes, saves the post and the ACF meta boxes before letting Divi open.
  - Highlights: red / green / amber. Featured image hint text corrected.
- Divi entry guard: on `template_redirect` @1, a `?et_fb` / `?et_fb_activation_nonce` request for an incomplete post is redirected to the editor with a notice.
- Publish guard:
  - `rest_request_before_callbacks` on `POST /divi/v1/sync-to-server`: `publish`/`future` is changed to `draft`. Layout content is still saved.
  - `transition_post_status` + `wp_after_insert_post` @99: a new publish of an incomplete post (block editor fallback, Quick Edit, Bulk Edit) is reverted to draft. In the block editor the check waits for the ACF meta-box request.
  - Already-live posts are never unpublished. Scheduled posts going live via cron are skipped.
- Notices: per-user transient `hs_post_gate_notice_{user}` (10 min), shown via `core/notices` or `admin_notices`.

**`deploy/posts-admin-columns.code-snippets.php`** (39 lines)
- The Posts list check uses the same rules, catches `et_fb_activation_nonce` links, and is bound at document level (`$(document).on`).
- New `post_class` filter `hs_posts_list_image_row_class` adds `hs-has-image` / `hs-no-image` to each row.

**`deploy/posts-register-fields.code-snippets.php`** (1 line): Portrait field instruction text only.

## Scope confirmation
- Only these 3 snippets were changed.
- No changes to WP core, Divi, ACF, the DB schema, settings, or other snippets.
- No new AJAX or REST endpoints, and no capability changes.

## Security
- The redirect uses `wp_safe_redirect`, only for users who pass `current_user_can( 'edit_post' )`.
- Output is escaped (`esc_html`, `wp_json_encode`).
- The REST filter is limited to one Divi route and can only downgrade publish to draft.

## Performance
Negligible:
- The REST filter returns immediately unless the route is Divi's save route.
- The entry guard only does work when `et_fb` is in the query string.
- The Posts list makes one `has_post_thumbnail()` call per row (cached meta).
- The editor's 250ms highlight polling existed before.
- Transients are short-lived (10 and 2 minutes).

## Live-site behaviour changes
- Live posts with **no Featured Image** (including posts with only a Portrait image) can't be updated in the block editor or opened in Divi until one is added.
- Quick Edit or Bulk Edit to Published on an incomplete post reverts it to Draft.
- Divi 5 beta may not explain a publish that was changed to draft. The reason is shown in WP admin.

## Deploy
1. Back up the current live snippets: "Posts--Divi-Gatekeeper", "Posts--Admin-Columns", "Posts--Register-Fields".
2. Paste the contents of `deploy/` into the matching Code Snippets entries.
3. Keep the gatekeeper set to **run everywhere** (admin + front end; the entry guard runs on the front end).
4. Run the test checklist in `DEV-BRIEF-posts-gatekeeper.md`.

## Rollback
Paste the files from `rollback/` (untouched originals) back into the same snippets.

## Verified
- `php -l` passes on all deploy files. The editor/list JS passes `node --check`.
- No function-name collisions.
- Local site returns HTTP 200 with no PHP errors.
- Owner confirmed in the browser: drafts save, Divi is blocked when fields are missing, highlights are correct.
- Still to test: the amber warning and checklist steps 3–8.
